﻿namespace Consolidador.Domain.SaldoDiario;

public interface ISaldoDiarioRepository
{
    SaldoDiario Add(SaldoDiario saldoDiario);
    SaldoDiario Update(SaldoDiario saldoDiario);
    Task<SaldoDiario?> ObterSaldoDia(DateTime data);
}