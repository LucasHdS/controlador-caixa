﻿namespace Consolidador.Domain.SaldoDiario;

public class SaldoDiarioNotFoundException(DateTime data) : Exception($"Saldo do dia {data.Date} nao encontrado");
