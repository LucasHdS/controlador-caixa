﻿using Core.Common;

namespace Consolidador.Domain.SaldoDiario;
public class SaldoDiario : Entity
{
    public DateTime Data { get; private set; }
    public decimal Valor { get; private set; }

    private SaldoDiario() { }

    public SaldoDiario(DateTime data, decimal valor) : base()
    {
        Data = data;
        Valor = valor;
    }

    public void AtualizarSaldo(decimal valor)
    {
        Valor += valor;
    }
}

