﻿using Consolidador.Domain.SaldoDiario;
using Microsoft.EntityFrameworkCore;

namespace Consolidador.Application.Abstractions.Data;
public interface IApplicationDbContext
{
    DbSet<SaldoDiario> SaldosDiarios { get; set; }
}
