﻿using Consolidador.Application.Abstractions.Data;
using Consolidador.Domain.SaldoDiario;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace Consolidador.Application.Consolidado.ObterSaldoDiario;

internal sealed class ObterSaldoDiarioQueryHandler(IApplicationDbContext context) : IRequestHandler<ObterSaldoDiarioQuery, SaldoDiarioResponse>
{
    public async Task<SaldoDiarioResponse> Handle(ObterSaldoDiarioQuery request, CancellationToken cancellationToken)
    {
        var saldoDiario = await context.SaldosDiarios
                                .AsNoTracking().
                                 FirstOrDefaultAsync(s => s.Data.Date == request.Data, cancellationToken: cancellationToken) 
                                 ?? throw new SaldoDiarioNotFoundException(request.Data);

        return new SaldoDiarioResponse(saldoDiario.DataCadastro, saldoDiario.Valor);
    }
}