﻿namespace Consolidador.Application.Consolidado.ObterSaldoDiario;
public record SaldoDiarioResponse(DateTime Data, decimal Valor);