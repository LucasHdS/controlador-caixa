﻿using MediatR;

namespace Consolidador.Application.Consolidado.ObterSaldoDiario;
public record ObterSaldoDiarioQuery(DateTime Data) : IRequest<SaldoDiarioResponse>;