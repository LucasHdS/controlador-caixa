﻿using Core.Abstractions.Messaging;

namespace Consolidador.Application.Consolidado.AtualizarSaldoDiario;

public record AtualizarSaldoDiarioCommand(decimal Valor, DateTime DataLancamento) : ICommand<Guid>;