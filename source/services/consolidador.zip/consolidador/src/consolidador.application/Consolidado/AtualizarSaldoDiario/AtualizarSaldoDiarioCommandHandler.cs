﻿using Consolidador.Domain.SaldoDiario;
using MediatR;

namespace Consolidador.Application.Consolidado.AtualizarSaldoDiario;
internal sealed class AtualizarSaldoDiarioCommandHandler : IRequestHandler<AtualizarSaldoDiarioCommand, Guid>
{
    private readonly ISaldoDiarioRepository _saldoDiarioRepository;

    public AtualizarSaldoDiarioCommandHandler(ISaldoDiarioRepository saldoDiarioRepository)
    {
        _saldoDiarioRepository = saldoDiarioRepository;
    }

    public async Task<Guid> Handle(AtualizarSaldoDiarioCommand request, CancellationToken cancellationToken)
    {
        var saldoDiario = await _saldoDiarioRepository.ObterSaldoDia(request.DataLancamento.Date);

        if (saldoDiario is null)
            saldoDiario = CadastrarSaldo(request);
        else
            AtualizarSaldo(saldoDiario, request.Valor);

        return saldoDiario.Id;
    }

    private SaldoDiario CadastrarSaldo(AtualizarSaldoDiarioCommand request)
    {
        var saldoDiario = new SaldoDiario(request.DataLancamento.Date, request.Valor);
        return _saldoDiarioRepository.Add(saldoDiario);
    }

    private SaldoDiario AtualizarSaldo(SaldoDiario saldoDiario, decimal valor)
    {
        saldoDiario.AtualizarSaldo(valor);
        return _saldoDiarioRepository.Update(saldoDiario);
    }
}