﻿using System.Reflection;

namespace Consolidador.Application;
public class ApplicationAssemblyReference
{
    internal static readonly Assembly Assembly = typeof(ApplicationAssemblyReference).Assembly;
}