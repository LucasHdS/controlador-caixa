﻿using Consolidador.Application.Consolidado.AtualizarSaldoDiario;
using Core.Abstractions.Messaging;
using IntegrationEvents;
using MediatR;

namespace Consolidador.Application.Lancamentos;

internal class LancamentoRealizadoIntegrationEventHandler : IIntegrationEventHandler<LancamentoRealizadoIntegrationEvent>
{
    private readonly ISender _sender;

    public LancamentoRealizadoIntegrationEventHandler(ISender sender)
    {
        _sender = sender;
    }

    public Task HandleAsync(LancamentoRealizadoIntegrationEvent @event, CancellationToken cancellationToken = default)
    {
        _sender.Send(new AtualizarSaldoDiarioCommand(@event.Valor, @event.DataLancamento));

        return Task.CompletedTask;
    }
}